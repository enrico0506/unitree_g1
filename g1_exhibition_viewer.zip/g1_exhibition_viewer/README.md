# G1 Exhibition Preview (runs on your own computer, robot not required)

This is a self-contained preview of the G1's planned "exhibition mode": it
roams around inside a 3-metre circle, pauses to do arm gestures, notices a
person, and can perform its one verified dance on request — all decided by
the exact same logic that will run on the real robot. It uses **mujoco**'s
own real 3D viewer, showing the actual G1 robot model.

It never connects to the real robot in any way — no network connection to
the Jetson, no Unitree SDK, nothing. It's just a physics/graphics sandbox
running entirely on your machine.

## 1. Install Python (if you don't already have it)

You need Python 3.9 or newer.
- **Windows**: https://www.python.org/downloads/ (check "Add python.exe to PATH" during install)
- **Mac**: `python3 --version` in Terminal — if missing, install from python.org, or `brew install python`
- **Linux**: almost certainly already installed (`python3 --version`)

## 2. Install the two packages this needs

Open a terminal (Command Prompt/PowerShell on Windows, Terminal on Mac/Linux)
in this folder, then run:

```
pip install -r sim/requirements.txt
```

(If `pip` isn't recognized, try `pip3` or `python3 -m pip install -r sim/requirements.txt`.)

This installs `mujoco` (the physics/rendering engine) and `pyyaml` (reads the
tuning config). Takes under a minute.

## 3. Run it

```
python3 scripts/sim_runner.py --viewer --demo-person --demo-dance-request
```

(On Windows, `python3` may need to just be `python`.)

A window should open showing the G1 model. It will:
- Walk to varied points inside the 3m circle
- Occasionally pause to wave / gesture
- Every so often, a synthetic person appears nearby — watch it pause, turn
  to face them, wave, and resume
- Every ~60 seconds, an automatic dance request gets queued and performed
  when it's safe to do so (this simulates what pressing "Dance" on the real
  dashboard will eventually do)

Close the window, or press Ctrl-C in the terminal, to stop.

### Useful variations
- `python3 scripts/sim_runner.py --viewer` — just the exhibition behavior, no
  scripted person/dance (quieter, good for watching the roam/gesture mix).
- `python3 scripts/sim_runner.py --viewer --no-exhibition` — plain
  circle-walking only, no roam/gesture/dance (the simpler baseline behavior).
- Add `--radius 2.0` or `--speed 0.7` to change the circle size / walking speed.

## If the window doesn't open

Mujoco's viewer needs a real screen — it will print `could not initialize
GLFW` (or similar) and exit if it can't find one. This should only happen if
you're running this over SSH/remote-desktop without a real display attached;
it's designed to run on your own computer's own screen, which should always
work.

## What this is / isn't

- **Is**: the real mujoco physics/rendering engine, the real G1 robot model,
  driven by the exact decision-making code (`g1_nav/g1_nav/patrol_logic.py`)
  planned for the real robot.
- **Isn't**: real balance physics — the legs animate for visual plausibility,
  but the robot's body position is directly computed from its intended
  velocity (no falling, no real walking dynamics). It also isn't obstacle-
  aware (there's nothing to avoid in this preview) and doesn't talk to any
  camera/microphone/sensor — the "person appears" and "dance requested"
  events are just scripted for the demo.
